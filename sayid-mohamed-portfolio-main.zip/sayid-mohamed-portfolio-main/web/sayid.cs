*{
margin: 0;
padding: 0;
    box - sizing: border - box;
     background-color: rgba(239, 12, 12, 1);
}
body{
    background-color: rgba(239, 12, 12, 1);
    font-family: Arial, Helvetica, sans-serif;

}